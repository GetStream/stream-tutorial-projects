import SwiftUI
import EffectsLibrary

struct HighIntensityFireworks: View {
    
    var config = FireworksConfig(
        content: [
            .shape(.triangle, .blue, 2.0),
            .shape(.square, .green, 1.0),
            .shape(.circle, nil, 2.0),
            .emoji("🔥", 5),
            .emoji("🎆", 5),
            .emoji("🪵", 10)
        ],
        intensity: .high,
        lifetime: .long,
        initialVelocity: .fast,
        fadeOut: .slow,
        spreadRadius: .high
    )
    
    var body: some View {
        FireworksView(config: config)
    }
}

struct HighIntensityFireworks_Previews: PreviewProvider {
    static var previews: some View {
        HighIntensityFireworks()
            .preferredColorScheme(.dark)
    }
}
