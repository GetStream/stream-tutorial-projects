//
//  CustomUIFactory.swift

import SwiftUI
import StreamChat
import StreamChatSwiftUI
import EffectsLibrary

class CustomUIFactory: ViewFactory {
    @Injected(\.chatClient) public var chatClient
    
    private init() {}
    
    public static let shared = CustomUIFactory()
    
    func makeReactionsBackgroundView(
        currentSnapshot: UIImage,
        popInAnimationInProgress: Bool
    ) -> some View {
        
        // Add the effects as the background of the emoji reactions
        //SnowView()
        HighIntensityFireworks()
        //FireView()
        //ConfettiView()
        //FireworksView()
        //RainView()
        //SmokeView()
    }
    
    // Add the Effects Library fireworks, and snow views as overlay on the chat bubbles
    /*func makeMessageTextView(
        for message: ChatMessage,
        isFirst: Bool,
        availableWidth: CGFloat,
        scrolledId: Binding<String?>) -> some View {
            Text(message.text)
                .padding()
                .messageBubble(for: message, isFirst: isFirst)
                .overlay(
                    BottomRightView {
                        //SnowView()
                        FireworksView()
                            .offset(x: 1, y: -1)
                            .cornerRadius(16)
                        //RainView()
                    }
                )
        }*/
    
    // 3.
    /*func makeMessageListBackground(
     colors: ColorPalette,
     isInThread: Bool
     ) -> some View {
     ZStack {
     LinearGradient(gradient: Gradient(
     colors: [.blue, .red, .white]),
     startPoint: .topLeading,
     endPoint: .bottomTrailing
     )
     .opacity(0.15)
     
     FireworksView()
     }
     }*/
    
}
