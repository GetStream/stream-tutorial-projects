//
//  ContentView.swift
//  Effects Library Stream Chat SwiftUI

import SwiftUI
import EffectsLibrary

struct ContentView: View {
    var config = FireworksConfig()
    
    var body: some View {
        //SnowView()
        //RainView()
        //FireView()
        //SmokeView()
        ConfettiView()
        //FireworksView(config: config)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .preferredColorScheme(.dark)
    }
}
