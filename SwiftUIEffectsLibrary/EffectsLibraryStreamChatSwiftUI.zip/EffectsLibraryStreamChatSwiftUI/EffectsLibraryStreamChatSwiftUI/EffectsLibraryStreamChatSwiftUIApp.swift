//
//  EffectsLibraryStreamChatSwiftUIApp.swift
//  EffectsLibraryStreamChatSwiftUI
//

import SwiftUI
import StreamChat
import StreamChatSwiftUI

@main
struct EffectsLibraryStreamChatSwiftUIApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    var body: some Scene {
        WindowGroup {
            // Display the channel list screen
            ChatChannelListView(viewFactory: CustomUIFactory.shared)
        }
    }
}
