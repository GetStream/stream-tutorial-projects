//
//  MicButtonView.swift
//  VoiceDorm
//
//  Created by amos.gyamfi@getstream.io on 17.7.2023.
//

import SwiftUI
import StreamVideo

// You can read & manage the microphone status from the call.microphone published variable
struct MicButtonView: View {
    @ObservedObject var microphone: MicrophoneManager

    var body: some View {
        Button {
           Task {
               try await microphone.toggle()
           }
        } label: {
            Image(systemName: microphone.status == .enabled ? "mic.circle" : "mic.slash.circle")
                .foregroundColor(microphone.status == .enabled ? .red : .primary)
                .font(.title)
        }
    }
}


