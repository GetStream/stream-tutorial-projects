//
//  ControlsView.swift
//  VoiceDorm
//
//  Created by amos.gyamfi@getstream.io on 17.7.2023.
//

import SwiftUI
import StreamVideo

// Step 7: Controls view with mic update. pass the microphone ObservedObject from the ControlsView
struct ControlsView: View {
    var call: Call
    @ObservedObject var state: CallState

    var body: some View {
        HStack {
            MicButtonView(microphone: call.microphone)
            LiveButtonView(call: call, state: state)
        }
    }
}

