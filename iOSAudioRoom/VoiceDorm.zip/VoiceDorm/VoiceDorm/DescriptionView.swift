//
//  DescriptionView.swift
//  VoiceDorm
//
//  Created by amos.gyamfi@getstream.io on 17.7.2023.
//

import SwiftUI
import StreamVideo

struct DescriptionView: View {
    var title: String?
    var description: String?
    var participants: [CallParticipant]
    @State private var animatedValue = 0
    
    var body: some View {
        NavigationStack {
            VStack {
                VStack {
                    Text("\(title ?? "")")
                        .font(.title)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .lineLimit(1)
                        .padding([.bottom], 8)
                    
                    Text("\(description ?? "")")
                        .font(.body)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .lineLimit(1)
                        .padding([.bottom], 4)
                }
                .padding([.leading, .trailing])
            }
            .toolbar {
                ToolbarItem(placement: .principal) {
                    VStack {
                        Text("Guests")
                            .font(.title)
                            .bold()
                        HStack {
                            Image(systemName: "person.2.fill")
                                .symbolEffect(
                                    .bounce.down.byLayer,
                                    options: .repeating.speed(0.1),
                                    value: animatedValue)
                                .onAppear {
                                    animatedValue = 1
                                }
                            Text("\(participants.count) participants")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
                
                ToolbarItem(placement: .topBarTrailing){
                    Image(systemName: "magnifyingglass")
                }
            }
        }
    }
}

#Preview {
    DescriptionView(participants: [])
        .preferredColorScheme(.dark)
}
