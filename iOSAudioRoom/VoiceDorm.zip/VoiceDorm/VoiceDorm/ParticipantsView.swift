//
//  ParticipantsView.swift
//  VoiceDorm
//
//  Created by amos.gyamfi@getstream.io on 17.7.2023.
//

import SwiftUI
import StreamVideo

struct ParticipantsView: View {
    var participants: [CallParticipant]

    var body: some View {
        LazyVGrid(columns: [GridItem(.adaptive(minimum: 100))], spacing: 20) {
            ForEach(participants) {
                ParticipantView(participant: $0)
            }
        }
    }
}

#Preview {
    ParticipantsView(participants: [])
}
