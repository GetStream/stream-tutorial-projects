//
//  VoiceDormApp.swift
//  VoiceDorm
//
//  Created by amos.gyamfi@getstream.io on 17.7.2023.
//

import SwiftUI
import StreamVideo

@main
struct VoiceDormApp: App {
    @State var call: Call
    @ObservedObject var state: CallState
    @State private var callCreated: Bool = false
    
    private var client: StreamVideo
    private let apiKey: String = "hd8szvscpxvd" // The API key can be found in the Credentials section
    private let userId: String = "Revan" // The User Id can be found in the Credentials section
    private let token: String = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiUmV2YW4iLCJpc3MiOiJwcm9udG8iLCJzdWIiOiJ1c2VyL1JldmFuIiwiaWF0IjoxNjkwODgzODgzLCJleHAiOjE2OTE0ODg2ODh9.bpQXCWWoUlFm1WYVVIckAB8fpqs8nce4bhMavEuzXso" // The Token can be found in the Credentials section
    private let callId: String = "EHElKKJjnJCd" // The CallId can be found in the Credentials section
    
    init() {
        let user = User(
            id: userId,
            name: "Amos", // name and imageURL are used in the UI
            imageURL: .init(string: "https://picsum.photos/id/64/200/200")
        )
        
        // Initialize Stream Video client
        self.client = StreamVideo(
            apiKey: apiKey,
            user: user,
            token: .init(stringLiteral: token)
        )
        
        // Initialize the call object
        let call = client.call(callType: "audio_room", callId: callId)
        
        self.call = call
        self.state = call.state
    }
    
    // Step 8: Updated app scene with participants grouping
    var body: some Scene {
        WindowGroup {
            NavigationStack {
                ScrollView(.vertical, showsIndicators: false) {
                    VStack {
                        if callCreated {
                            DescriptionView(
                                title: call.state.custom["title"]?.stringValue,
                                description: call.state.custom["description"]?.stringValue,
                                participants: call.state.participants
                            )
                            
                            HStack {
                                Text("Speakers")
                                    .font(.title2)
                                    .bold()
                                Spacer()
                            }
                            
                            Divider()
                            
                            ParticipantsView(
                                participants: call.state.participants.filter {$0.hasAudio}
                            )
                            
                            Divider()
                            
                            HStack {
                                Text("Listeners")
                                    .font(.title2)
                                    .bold()
                                    .padding(.top)
                                Spacer()
                            }
                            
                            Divider()
                            
                            ParticipantsView(
                                participants: call.state.participants.filter {!$0.hasAudio}
                            )
                            
                            Spacer()
                            
                            PermissionRequestsView(call: call, state: state)
                            ControlsView(call: call, state: state)
                        } else {
                            Text("loading...")
                        }
                    }
                    .padding(.horizontal)
                    .task {
                        Task {
                            guard !callCreated else { return }
                            try await call.join(
                                create: true,
                                options: .init(
                                    members: [
                                        .init(userId: "john_smith"),
                                        .init(userId: "jane_doe"),
                                    ],
                                    custom: [
                                        "title": .string("SwiftUI heads"),
                                        "description": .string("Talking about SwiftUI")
                                    ]
                                )
                            )
                            try await call.sendReaction(type: "raise-hand", custom: ["mycustomfield": "hello"], emojiCode: ":smile:")
                            callCreated = true
                        }
                    }
                }
            }
        }
    }
}
