//
//  PermissionRequestView.swift
//  VoiceDorm
//
//  Created by amos.gyamfi@getstream.io on 17.7.2023.
//

import SwiftUI
import StreamVideo

struct PermissionRequestsView: View {
    var call: Call
    @ObservedObject var state: CallState

    var body: some View {
        if let request = state.permissionRequests.first {
            VStack {
                Text("\(request.user.name) requested to \(request.permission)")
                HStack(spacing: 32) {
                    Button {
                       Task {
                           try await call.grant(request: request)
                       }
                    } label: {
                        Label("Accept", systemImage: "hand.thumbsup.circle").tint(.green)
                    }
                    .buttonStyle(.borderedProminent)
                    
                    Button(action: request.reject) {
                        Label("Reject", systemImage: "hand.thumbsdown.circle.fill").tint(.red)
                    }
                    .buttonStyle(.bordered)
                }
                .padding(EdgeInsets(top: 16, leading: 0, bottom: 32, trailing: 0))
            }
        }
    }
}


