//
//  StartNewFace2FaceView.swift
//  Face2Face
//
//  Created by amos.gyamfi@getstream.io on 4.8.2023.
//

import SwiftUI

struct StartNewFace2FaceView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    StartNewFace2FaceView()
}
