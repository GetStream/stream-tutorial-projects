//
//  CustomVideoViewFactory.swift
//  AIVideoEffectsFilters
//
//  Created by Amos Gyamfi on 17.8.2025.
//

import SwiftUI
import StreamVideoSwiftUI

class VideoViewFactory: ViewFactory {
    func makeCallControlsView(viewModel: CallViewModel) -> some View {
        ChatCallControls(viewModel: viewModel)
    }
}
