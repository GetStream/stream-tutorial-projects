//
//  ChatCallControls.swift
//  AIVideoEffectsFilters
//
//  Created by Amos Gyamfi on 17.8.2025.
//

import SwiftUI
import StreamVideo
import StreamVideoSwiftUI

// Glass effect modifier for filter buttons
extension View {
    func glassEffect() -> some View {
        self
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12))
            .foregroundColor(.primary)
    }
}

struct ChatCallControls: View {
    @ObservedObject var filtersService: FiltersService
    @ObservedObject var viewModel: CallViewModel
    let size: CGFloat = 44
    init(viewModel: CallViewModel, filtersService: FiltersService? = nil) {
        self._viewModel = ObservedObject(initialValue: viewModel)
        // If a FiltersService is passed in, use it; otherwise create a local instance to avoid runtime crashes.
        self._filtersService = ObservedObject(initialValue: filtersService ?? FiltersService())
    }
    var body: some View {
        VStack {
            HStack {
                /* Skip unrelated code */
                // 1. Button to toggle filters view
                Button {
                    withAnimation(.bouncy) {
                        filtersService.filtersShown.toggle()
                    }
                } label: {
                    CallIconView(
                        icon: Image(systemName: "camera.filters"),
                        size: size,
                        iconStyle: filtersService.filtersShown ? .primary : .transparent
                    )
                }
                /* Skip unrelated code */
            }
            
            if filtersService.filtersShown {
                HStack(spacing: 16) {
                    // 2. Show a button for each filter
                    ForEach(FiltersService.supportedFilters, id: \.id) { filter in
                        Button {
                            withAnimation(.bouncy) {
                                // 3. Select or de-select filter on tap
                                if filtersService.selectedFilter?.id == filter.id {
                                    filtersService.selectedFilter = nil
                                } else {
                                    filtersService.selectedFilter = filter
                                }
                                viewModel.setVideoFilter(filtersService.selectedFilter)
                            }
                        } label: {
                            Text(filter.name)
                                //.background(filtersService.selectedFilter?.id == filter.id ? Color.blue : Color.gray)
                                .padding()
                                .glassEffect()
                                .padding(.top, 32)
                            /* more modifiers */
                        }
                    }
                }
            }
        }
        /* more modifiers */
    }
}

