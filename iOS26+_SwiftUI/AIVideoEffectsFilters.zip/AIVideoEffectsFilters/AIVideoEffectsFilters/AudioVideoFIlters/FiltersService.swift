// FiltersService.swift
// Shared video filter service for all call-related views
import Foundation
import Combine
import StreamVideo
import CoreImage

let sepia: VideoFilter = {
    let sepia = VideoFilter(id: "sepia", name: "Sepia") { input in
        let sepiaFilter = CIFilter(name: "CISepiaTone")
        sepiaFilter?.setValue(input.originalImage, forKey: kCIInputImageKey)
        return sepiaFilter?.outputImage ?? input.originalImage
    }
    return sepia
}()

let bloom: VideoFilter = {
    let bloom = VideoFilter(id: "bloom", name: "Bloom") { input in
        let bloomFilter = CIFilter(name: "CIBloom")
        bloomFilter?.setValue(input.originalImage, forKey: kCIInputImageKey)
        bloomFilter?.setValue(1.0, forKey: kCIInputIntensityKey) // Intensity of the bloom effect
        bloomFilter?.setValue(10.0, forKey: kCIInputRadiusKey) // Radius of the bloom effect
        return bloomFilter?.outputImage ?? input.originalImage
    }
    return bloom
}()

let blur: VideoFilter = {
    let blur = VideoFilter(id: "blur", name: "Blur") { input in
        let blurFilter = CIFilter(name: "CIGaussianBlur")
        blurFilter?.setValue(input.originalImage, forKey: kCIInputImageKey)
        blurFilter?.setValue(5.0, forKey: kCIInputRadiusKey) // Blur radius
        
        // Blur filter expands the image bounds, so we need to crop it back to original extent
        if let blurredImage = blurFilter?.outputImage {
            let originalExtent = input.originalImage.extent
            return blurredImage.cropped(to: originalExtent)
        }
        return input.originalImage
    }
    return blur
}()

class FiltersService: ObservableObject {
    @Published var filtersShown = false
    @Published var selectedFilter: VideoFilter?

    static let supportedFilters = [sepia, bloom, blur]
}
