//
//  AIVideoEffectsFiltersApp.swift
//  AIVideoEffectsFilters
//
//  Created by Amos Gyamfi on 11.8.2025.
//

import SwiftUI
import Combine
import StreamVideo
import StreamVideoSwiftUI

@main
struct AIVideoEffectsFiltersApp: App {
    @ObservedObject var viewModel: CallViewModel

    private var client: StreamVideo

    private let apiKey: String = "mmhfdzb5evj2"
    private let token: String = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJodHRwczovL3Byb250by5nZXRzdHJlYW0uaW8iLCJzdWIiOiJ1c2VyL0NsZWFuX1B1bmNoIiwidXNlcl9pZCI6IkNsZWFuX1B1bmNoIiwidmFsaWRpdHlfaW5fc2Vjb25kcyI6NjA0ODAwLCJpYXQiOjE3NTYxMTAwMzksImV4cCI6MTc1NjcxNDgzOX0.J27Xu8VeMH981549GoQWQEuPDvLsdi1C9kf36s-54p4"
    private let userId: String = "Clean_Punch"
    private let callId: String = "vnQnRfMbgTxJF1jYP4PsK"
    
    // Audio & video filters are now defined in FiltersService.swift

    init() {
        let user = User(
            id: userId,
            name: "Martin", // name and imageURL are used in the UI
            imageURL: .init(string: "https://getstream.io/static/2796a305dd07651fcceb4721a94f4505/a3911/martin-mitrevski.webp")
        )

        // Initialize Stream Video client
        self.client = StreamVideo(
            apiKey: apiKey,
            user: user,
            token: .init(stringLiteral: token),
            // Audio & video filters
            videoConfig: VideoConfig(
                    videoFilters: FiltersService.supportedFilters
                ),
        )

        self.viewModel = .init()
    }

    var body: some Scene {
        WindowGroup {
            VStack {
                if viewModel.call != nil {
                    // Previous: DefaultViewFactory.shared
                    CallContainer(viewFactory: VideoViewFactory(), viewModel: viewModel)
                } else {
                    Text("loading...")
                }
            }.onAppear {
                Task {
                    guard viewModel.call == nil else { return }
                    viewModel.joinCall(callType: .default, callId: callId)
                }
            }
        }
    }
}
