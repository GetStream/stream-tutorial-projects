# ``FacebookLiveClone``

Building Fun SwiftUI Animations: Comments and Emoji Reactions For Live Events

## Learn SwiftUI animation techniques to build animated comments and emoji reactions. 

A series of 9 tutorials helping you to animate easily in SwiftUI. 

## Topics

### <!--@START_MENU_TOKEN@-->Group<!--@END_MENU_TOKEN@-->

- <!--@START_MENU_TOKEN@-->``Symbol``<!--@END_MENU_TOKEN@-->
