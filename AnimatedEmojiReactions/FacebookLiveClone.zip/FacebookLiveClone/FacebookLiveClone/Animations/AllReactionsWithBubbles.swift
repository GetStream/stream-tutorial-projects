//
//  AllReactionWithComments.swift
//  FacebookLiveClone
//

import SwiftUI

struct AllReactionsWithBubbles: View {
    var body: some View {
        NavigationStack {
            ZStack {
                HostedViewController()
                    .ignoresSafeArea()
                VStack {
                    TopView()
                    Spacer()
                    SVGCharacterView()
                    ComposeAreaView()
                }
                .padding()
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    RecordingView()
                }
            }
        }
    }
}

struct AllReactionsWithBubbles_Previews: PreviewProvider {
    static var previews: some View {
        AllReactionsWithBubbles()
            .preferredColorScheme(.dark)
    }
}
