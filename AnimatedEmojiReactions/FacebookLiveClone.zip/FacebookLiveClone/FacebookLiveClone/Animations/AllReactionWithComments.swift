//
//  AllReactionWithComments.swift
//  FacebookLiveClone
//

import SwiftUI

struct AllReactionWithComments: View {
    @State private var isKeyframe0 = false
    @State private var isKeyframe1 = false
    @State private var isKeyframe2 = false
    @State private var isKeyframe3 = false
    @State private var isKeyframe4 = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                HostedViewController()
                    .ignoresSafeArea()
                
                VStack {
                    TopView()
                    
                    Color(.black)
                        .frame(width: UIScreen.main.bounds.width, height: 300)
                        .zIndex(1)
                        .blur(radius: 25, opaque: false)
                        .blendMode(.plusDarker)

                    CommentsView(comments: CommentsData)
                        .offset(y: isKeyframe0 ? -50 : 0)
                        .onAppear{
                            withAnimation(.easeInOut(duration: 1)){
                                isKeyframe0.toggle()
                            }
                        }
                        .offset(y: isKeyframe1 ? -50 : 0)
                        .onAppear{
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                                withAnimation(.easeInOut(duration: 1)){
                                    isKeyframe1.toggle()
                                }
                            }
                        }
                        .offset(y: isKeyframe2 ? -50 : 0)
                        .onAppear{
                            DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
                                withAnimation(.easeInOut(duration: 1)){
                                    isKeyframe2.toggle()
                                }
                            }
                        }
                        .offset(y: isKeyframe3 ? -50 : 0)
                        .onAppear{
                            DispatchQueue.main.asyncAfter(deadline: .now() + 6) {
                                withAnimation(.easeInOut(duration: 1)){
                                    isKeyframe3.toggle()
                                }
                            }
                        }
                        .offset(y: isKeyframe4 ? -50 : 0)
                        .onAppear{
                            DispatchQueue.main.asyncAfter(deadline: .now() + 8) {
                                withAnimation(.easeInOut(duration: 1)){
                                    isKeyframe4.toggle()
                                }
                            }
                        }
                    
                    ComposeAreaView()
                        .zIndex(2)
                }
                .padding()
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    RecordingView()
                }
            }
        }
    }
}

struct AllReactionWithComments_Previews: PreviewProvider {
    static var previews: some View {
        AllReactionWithComments()
            .preferredColorScheme(.dark)
    }
}
