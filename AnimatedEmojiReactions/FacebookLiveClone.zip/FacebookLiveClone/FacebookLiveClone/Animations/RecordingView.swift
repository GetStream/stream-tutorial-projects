//
//  RecordingView.swift
//  SwiftUICallingKit
//

import SwiftUI

struct RecordingView: View {
    @State private var counter: Int = 0
    private let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    @State private var isVisible: Bool = false
    
    var body: some View {
        VStack {
            HStack {
                Image(systemName: "mic.fill")
                    .fontWeight(.bold)
                    .opacity(isVisible ? 0 : 1)
                    .foregroundColor(Color(.systemRed))
                    .animation(.easeInOut(duration: 0.5).repeatForever(autoreverses: true), value: isVisible)
                    .onAppear {
                        isVisible = true
                    }
                
                Text("\(counter)")
                    .onReceive(timer) { _ in
                        counter += 1
                    }
                
                Spacer()
                
                HStack {
                    Text("slide to cancel")
                    Image(systemName: "chevron.left")
                }
                .foregroundColor(.secondary)
                
                Spacer()
                
                Button {
                    
                } label: {
                    Image(systemName: "mic")
                }
            }
        }
        .padding()
    }
}

struct RecordingView_Previews: PreviewProvider {
    static var previews: some View {
        RecordingView()
    }
}
