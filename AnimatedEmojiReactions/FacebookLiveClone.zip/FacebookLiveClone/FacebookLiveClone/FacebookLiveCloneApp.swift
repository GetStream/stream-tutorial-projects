//
//  FacebookLiveCloneApp.swift
//  FacebookLiveClone
//

import SwiftUI

@main
struct FacebookLiveCloneApp: App {
    var body: some Scene {
        WindowGroup {
            AllReactionWithComments()
            //AllReactionsWithBubbles()
        }
    }
}
