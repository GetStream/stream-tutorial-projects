//
//  TopView.swift
//  FacebookLiveClone
//

import SwiftUI

struct TopView: View {
    let today = Date.now.formatted(date: .abbreviated, time: .shortened)
    let time = Date()
    
    var body: some View {
        HStack(alignment: .top) {
            Text("Live")
                .padding(EdgeInsets(top: 8, leading: 24, bottom: 8, trailing: 24))
                .background(.red)
                .cornerRadius(8)
            
            Label("4.5k", systemImage: "eye.fill")
                .padding(EdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16))
                .background(Color(.systemGray5))
                .cornerRadius(8)
            
            Spacer()
            
            Text(today)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding()

    }
}

struct TopView_Previews: PreviewProvider {
    static var previews: some View {
        TopView()
            .preferredColorScheme(.dark)
    }
}
