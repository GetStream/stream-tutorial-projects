//
//  ComposeAreaView.swift
//  FacebookLiveClone
//

import SwiftUI

struct ComposeAreaView: View {
    @State private var writeComment = ""
    let streamBlue =
        Color(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1))
    var body: some View {
        VStack(alignment: .leading) {
            Label("Comments  *  2.5k", systemImage: "chevron.down")
            
            HStack {
                Image(systemName: "arrowshape.turn.up.right.circle.fill")
                    .font(.largeTitle)
                
                ZStack(alignment: .trailing) {
                    TextField("Write your comment", text: $writeComment)
                        .frame(width: 160)
                        .font(.caption)
                        .padding() 
                        .background(Color(.systemGray6).gradient)
                        .cornerRadius(20, corners: [.topRight, .bottomLeft])
                        .cornerRadius(6, corners: [.bottomRight, .topLeft])
                        
                    Image(systemName: "paperplane.fill")
                        .padding()
                }
                
                ReactionsView()
            }
            
            
        }
    }
}

struct ComposeAreaView_Previews: PreviewProvider {
    static var previews: some View {
        ComposeAreaView()
            .preferredColorScheme(.dark)
    }
}
