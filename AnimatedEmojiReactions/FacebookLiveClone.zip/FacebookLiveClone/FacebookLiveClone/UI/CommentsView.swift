//
//  CommentsView.swift
//  FacebookLiveClone

import SwiftUI

struct CommentsView: View {
    let streamSilver = #colorLiteral(red: 0.8374180198, green: 0.8374378085, blue: 0.8374271393, alpha: 1)
    let streamTungsten = #colorLiteral(red: 0.2605174184, green: 0.2605243921, blue: 0.260520637, alpha: 1)
    
    var comments: [CommentsStructure] = []
    
    var body: some View {
        VStack(alignment: .leading) {
            ForEach(comments) { item in
                HStack(alignment: .top){
                    Image(item.avatar)
                        .resizable()
                        .symbolRenderingMode(.hierarchical)
                        .clipShape(Circle())
                        .frame(width: 45, height: 45)
                    
                    VStack(alignment: .leading) {
                        HStack {
                            Text("\(item.name)")
                                .font(.subheadline)
                                .bold()
                            Text("\(item.timestamp)")
                                .font(.caption2)
                        }
                        
                        Text("\(item.comment)")
                            .font(.caption)
                    }
                }
            }
            .listStyle(.plain)
        }
        .padding()
    }
}

struct CommentsView_Previews: PreviewProvider {
    static var previews: some View {
        CommentsView(comments: CommentsData)
            .preferredColorScheme(.dark)
    }
}
