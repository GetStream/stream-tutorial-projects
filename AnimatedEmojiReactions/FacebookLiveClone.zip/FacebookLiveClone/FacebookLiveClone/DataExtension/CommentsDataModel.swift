//
//  MessagesDataModel.swift
//  MessagesDataModel
//

import Foundation

// Data structure
struct CommentsStructure: Identifiable { // Identifiable protocol - makes it possible to use value types that needs to have a stable notion of identity.
    var id = UUID() // A universally unique identifier to identify a particular datafield and types
    var avatar: String
    var name: String
    var comment: String
    var timestamp: String
}

// Data storage using a dictionary. A dictionary stores items with key, value pairs. The order of items is not important when using dictionaries.
let CommentsData = [
    CommentsStructure(avatar: "anastasia", name: "Anastasia", comment: "That's great, I can help you with that!", timestamp: "13:30 AM"),
    CommentsStructure(avatar: "jaewoong", name: "Ama", comment: "Sad fact: just gives you gifs. ", timestamp: "13:30 AM"),
    CommentsStructure(avatar: "ally", name: "Ally", comment: "I don't know why people are so anti pineapple pizza? 🍕", timestamp: "13:30 AM"),
    CommentsStructure(avatar: "emily", name: "Emily", comment: "There's no way you'll be able to jump.😳", timestamp: "13:30 AM"),
    CommentsStructure(avatar: "stefan", name: "Stefan", comment: "Tabs make way more sense than spaces.", timestamp: "13:30 AM"),
    CommentsStructure(avatar: "amos", name: "Amos", comment: "you cannot search for a gif 🥰", timestamp: "13:30 AM")
]
