import SwiftUI
import StreamVideo
import StreamVideoSwiftUI

class CustomViewFactory: ViewFactory {
    
    // 1. Custom Outgoing Call
    func makeOutgoingCallView(viewModel: CallViewModel) -> some View {
        // Here you can also provide your own custom view.
        // In this example, we are re-using the standard one, while also adding an overlay.
        let outgoingView = DefaultViewFactory.shared.makeOutgoingCallView(viewModel: viewModel)
        return outgoingView.overlay(
            MessengerOutgoingCallView(viewModel: viewModel)
        )
    }
    
    // 2. Custom Call Controls
    public func makeCallControlsView(viewModel: CallViewModel) -> some View {
        MessengerControlsView(viewModel: viewModel)
    }
    
    // 3. Custom CallTopView
    public func makeCallTopView(viewModel: CallViewModel) -> some View {
        WhatsAppCallTopView()
    }
    
    // 4. Custom Active Call screen
    public func makeCallView(viewModel: CallViewModel) -> some View {
        TelegramActiveCallView(viewModel: viewModel)
    }
    
    func makeIncomingCallView(viewModel: CallViewModel, callInfo: IncomingCall) -> some View {
        CustomIncomingCallView(callInfo: callInfo, callViewModel: viewModel)
    }
}
