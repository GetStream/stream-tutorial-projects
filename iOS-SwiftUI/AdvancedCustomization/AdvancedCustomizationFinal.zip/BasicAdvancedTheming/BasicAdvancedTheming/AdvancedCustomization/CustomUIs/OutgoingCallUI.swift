//
//  OutgoingCallUI.swift
//  VideoSampleSwiftUI
//
//  Created by amos.gyamfi@getstream.io on 13.6.2023.
//

import SwiftUI

struct OutgoingCallUI: View {
    @State private var isReplaced = false
    @State private var value1 = 0
    @State private var value2 = 0
    
    var body: some View {
        NavigationStack {
            ZStack {
                HostedViewController()
                    .ignoresSafeArea()
                    .blur(radius: 10)
                    .blendMode(.plusLighter)
                
                VStack {
                    HStack(spacing: 32) {
                        VStack {
                            Image(systemName: "speaker.wave.2.circle.fill")
                                .font(.system(size: 48))
                                .symbolEffect(.variableColor)
                            Text("Speaker")
                        }
                        
                        VStack {
                            Image(systemName: "camera.circle.fill")
                                .font(.system(size: 48))
                            Text("Camera")
                        }
                        VStack {
                            Image(systemName: isReplaced ? "mic.slash.circle.fill" : "mic.circle.fill")
                                .font(.system(size: 48))
                                .contentTransition(
                                    .symbolEffect(
                                        .replace.offUp,
                                        options: .repeating))
                                .onAppear{
                                    self.isReplaced.toggle()
                                    self.value2 += 1
                                }
                            Text("Mute")
                        }
                        VStack {
                            Image(systemName: "phone.down.circle.fill")
                                .font(.system(size: 48))
                                .symbolRenderingMode(.multicolor)
                                .symbolEffect(
                                    .bounce.up.byLayer,
                                    options: .repeating,
                                    value: value1
                                )
                                .onAppear{
                                    self.value1 += 1
                                }
                            Text("End")
                        }
                    }
                    
                    Spacer()
                        
                    HStack(alignment: .bottom, spacing: 0) {
                        Text("Calling")
                        Image(systemName: "ellipsis")
                            .font(.title)
                            .bold()
                            .symbolEffect(
                                .variableColor.iterative.dimInactiveLayers.nonReversing
                            )
                    }
                    
                    Spacer()
                    
                    HStack(spacing: 64) {
                        Image(systemName: "wand.and.rays.inverse")
                            .foregroundStyle(LinearGradient(gradient: Gradient(colors: [Color.red, Color.blue]), startPoint: .leading, endPoint: .trailing))
                            .symbolEffect(.variableColor)
                        Image(systemName: "person.circle.fill")
                        Image(systemName: "arrow.triangle.2.circlepath.camera.fill")
                    }
                    .font(.system(size: 48))
                    .symbolRenderingMode(.hierarchical)
                }
                .padding()
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) {
                        Image(systemName: "info.circle")
                    }
                    
                    ToolbarItemGroup(placement: .topBarLeading) {
                        HStack {
                            Image(systemName: "h.circle.fill")
                                .font(.largeTitle)
                                .foregroundStyle(AngularGradient(gradient: Gradient(colors: [Color.red, Color.blue]), center: .center))
                            VStack(alignment: .leading) {
                                Text("Harrison")
                                HStack {
                                    Image(systemName: "video")
                                    Text("1 - 1 Video Call")
                                        .foregroundColor(.secondary)
                                }
                                .font(.caption)
                            }
                        }
                    }
            }
            }
        }
    }
}

#Preview {
    OutgoingCallUI()
        .preferredColorScheme(.dark)
}
