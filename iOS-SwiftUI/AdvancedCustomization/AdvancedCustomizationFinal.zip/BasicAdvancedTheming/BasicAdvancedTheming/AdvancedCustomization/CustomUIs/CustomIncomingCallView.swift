//
//  CustomIncomingCallView.swift
//  BasicAdvancedTheming
//
//  Created by amos.gyamfi@getstream.io on 12.9.2023.
//

import SwiftUI
import StreamVideo
import StreamVideoSwiftUI

struct CustomIncomingCallView: View {
    
    @Injected(\.colors) var colors
    
    @ObservedObject var callViewModel: CallViewModel
    @StateObject var viewModel: IncomingViewModel
                
    init(
        callInfo: IncomingCall,
        callViewModel: CallViewModel
    ) {
        self.callViewModel = callViewModel
        _viewModel = StateObject(
            wrappedValue: IncomingViewModel(callInfo: callInfo)
        )
    }
    
    var body: some View {
        VStack {
            Spacer()
            Text("Incoming call")
                .foregroundColor(Color(colors.textLowEmphasis))
                .padding()
            
            Image(.leenarts)
                .frame(width: 80, height: 80)
                .clipShape(RoundedRectangle(cornerRadius: 8))
                .padding()
            
            Text(callInfo.caller.name)
                .font(.title)
                .foregroundColor(Color(colors.textLowEmphasis))
                .padding()
            
            Spacer()
            
            HStack(spacing: 16) {
                Spacer()
                
                Button {
                    //callViewModel.rejectCall(callId: callInfo.id, type: callInfo.type)
                } label: {
                    Image(systemName: "phone.down.fill")
                        .foregroundColor(.white)
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color.red)
                                .frame(width: 60, height: 60)
                        )
                }
                .padding(.all, 8)
                                
                Button {
                    callViewModel.acceptCall(callType: .default, callId: callInfo.id)
                } label: {
                    Image(systemName: "phone.fill")
                        .foregroundColor(.white)
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color.green)
                                .frame(width: 60, height: 60)
                        )
                }
                .padding(.all, 8)
                
                Spacer()
            }
            .padding()
            
        }
        .background(Color.white.edgesIgnoringSafeArea(.all))
        .onChange(of: viewModel.hideIncomingCallScreen) { newValue in
            if newValue {
                callViewModel.rejectCall(callType: .default, callId: callInfo.id)
            }
        }
        .onDisappear {
            viewModel.stopTimer()
        }
    }
    
    var callInfo: IncomingCall {
        viewModel.callInfo
    }
    
}

