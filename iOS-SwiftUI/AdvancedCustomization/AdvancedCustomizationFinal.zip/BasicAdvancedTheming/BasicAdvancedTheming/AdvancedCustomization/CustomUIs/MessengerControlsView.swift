//
//  MessengerControlsView.swift

import SwiftUI
import StreamVideoSwiftUI

struct MessengerControlsView: View {
    
    @ObservedObject var viewModel: CallViewModel
    
    var body: some View {
        HStack(spacing: 32) {
            Button {
                viewModel.toggleCameraEnabled()
            } label: {
                Image(systemName: "video.fill")
                    .font(.title)
                    .foregroundStyle(.secondary)
            }
            .padding(.horizontal, 16)
            .buttonStyle(.plain)

            Button {
                viewModel.toggleMicrophoneEnabled()
            } label: {
                Image(systemName: "mic.fill")
                    .font(.title)
            }
            .buttonStyle(.plain)
            
            Button {
                viewModel.toggleCameraPosition()
            } label: {
                Image(systemName: "rectangle.stack.badge.play.fill")
                    .font(.title)
                    .foregroundStyle(.secondary)
            }
            .buttonStyle(.plain)
                        
            Button {
                viewModel.toggleCameraPosition()
            } label: {
                Image(systemName: "arrow.triangle.2.circlepath.camera.fill")
                    .font(.title)
            }
            .buttonStyle(.plain)
            
            HangUpIconView(viewModel: viewModel)
        }
        .frame(maxWidth: .infinity)
        .frame(height: 74)
        .background(.quaternary)
    }
    
}

