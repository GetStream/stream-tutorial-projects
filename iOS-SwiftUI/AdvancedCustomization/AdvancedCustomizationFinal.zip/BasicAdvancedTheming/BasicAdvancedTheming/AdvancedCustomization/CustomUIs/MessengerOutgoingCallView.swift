//
//  MessengerOutgoingCallView.swift

import SwiftUI
import StreamVideo
import StreamVideoSwiftUI

struct MessengerOutgoingCallView: View {
    @ObservedObject var viewModel: CallViewModel
    @State var callCreated: Bool = false
    
    @State private var isCalling = false
    let easeGently = Animation.easeOut(duration: 1).repeatForever(autoreverses: true)
    
    var body: some View {
        NavigationStack {
            ZStack {
                HostedViewController()
                    .blur(radius: 2)
                
                VStack {
                    ZStack {
                        Image("blob4")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 120, height: 120)
                            .opacity(0.1)
                            .scaleEffect(isCalling ? 0.8 : 1.8)
                            .offset(y: 60)
                            .animation(easeGently.delay(0.2), value: isCalling)
                            
                        Image("blob5")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 120, height: 120)
                            .opacity(0.2)
                            .scaleEffect(isCalling ? 0.8 : 1.7)
                            .offset(y: 60)
                            .animation(easeGently.delay(0.4), value: isCalling)
                        
                        Image("blob6")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 120, height: 120)
                            .opacity(0.3)
                            .scaleEffect(isCalling ? 0.7 : 1.5)
                            .offset(y: 60)
                            .animation(easeGently.delay(0.6), value: isCalling)
                        
                        Image(.leenarts)
                            .resizable()
                            .scaledToFit()
                            .clipShape(Circle())
                            .frame(width: 120, height: 120)
                            .padding(.top, 120)
                            .scaleEffect(isCalling ? 0.8 : 1)
                            .animation(easeGently, value: isCalling)
                    }
                    .onAppear {
                        withAnimation() {
                            isCalling.toggle()
                        }
                    }
                    
                        
                    Text("Jeroen Leenarts")
                        .font(.title.bold())
                    HStack(alignment: .bottom, spacing: 0) {
                        Text("Calling")
                        Image(systemName: "ellipsis")
                            .font(.title)
                            .bold()
                            .symbolEffect(
                                .variableColor.iterative.dimInactiveLayers.nonReversing
                            )
                    }
                    
                    HStack {
                        VStack(spacing: 32) {
                            Image(systemName: "theatermask.and.paintbrush.fill")
                            Image(systemName: "face.dashed.fill")
                            Image(systemName: "lightbulb.fill")
                            Image(systemName: "wand.and.stars.inverse")
                        }
                        .font(.title.bold())
                        
                        Spacer()
                    }
                    .padding(.top, 64)
                    .padding(.horizontal, 16)
                    
                    Spacer()
                    
                    MessengerControlsView(viewModel: viewModel)
                }
                
                Spacer()
            }
            .ignoresSafeArea()
            .toolbar {
                ToolbarItemGroup(placement: .topBarLeading) {
                    Image(systemName: "chevron.down")
                    Text("Jeroen Leenarts")
                        .bold()
                }
                
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Image(systemName:"person.fill.badge.plus")
                        .symbolEffect(
                            .pulse
                        )
                    Image(systemName:"ellipsis")

                }
            }
        }
    }
}



