//
//  WhatsAppCallTopView.swift
//  BasicAdvancedTheming
//
//  Created by amos.gyamfi@getstream.io on 11.9.2023.
//

import SwiftUI
import StreamVideoSwiftUI

struct WhatsAppCallTopView: View {
    
    var body: some View {
        HStack {
            Button {
                
            } label: {
                Image(systemName: "chevron.backward")
            }
            .font(.title2)
            .bold()

            
            Button {
                
            } label: {
                Text("33")
            }
            
            Spacer()
            
            Image(.leenarts)
                .resizable()
                .scaledToFit()
                .clipShape(Circle())
                .frame(width: 48, height: 48)
            Text("Jeroen Leenarts")
                .bold()
            
            Spacer()
            Spacer()
            
            Button {
                
            } label: {
                Image(systemName: "video")
            }
            .font(.title2)
            .bold()
           
            Button {
                
            } label: {
                Image(systemName: "phone")
            }
            .font(.title2)
            .bold()
        }
        .padding()
    }
}


