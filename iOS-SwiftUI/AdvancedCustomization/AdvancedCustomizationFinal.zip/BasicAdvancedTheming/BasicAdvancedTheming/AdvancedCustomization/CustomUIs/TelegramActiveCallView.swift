//
//  TelegramActiveCallView.swift
//  BasicAdvancedTheming
//
//  Created by amos.gyamfi@getstream.io on 12.9.2023.
//

import SwiftUI
import StreamVideoSwiftUI

struct TelegramActiveCallView: View {
    @ObservedObject var viewModel: CallViewModel
    
    let tv = "📺"
    let eightEmoji = "8️⃣"
    let castle = "🏰"
    let animal = "🐼"
    
    var body: some View {
        NavigationStack {
            ZStack {
                Image("martinmartz")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()
                VStack {
                    VStack {
                        Text("Hilder2")
                            .font(.title)
                        Text(Date.now.formatted())
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    
                    Spacer()
                    
                    VStack(spacing: 64) {
                        HStack(spacing: 32) {
                            Button {
                                viewModel.toggleCameraEnabled()
                            } label: {
                                VStack {
                                    Image(systemName: "video.circle.fill")
                                        .font(.largeTitle)
                                    Text("Camera")
                                }
                            }
                            .padding(.horizontal, 16)
                            .buttonStyle(.plain)
                            
                            Button {
                                viewModel.toggleMicrophoneEnabled()
                            } label: {
                                VStack{
                                    Image(systemName: "mic.circle.fill")
                                        .font(.largeTitle)
                                        .symbolRenderingMode(.hierarchical)
                                    Text("Mute")
                                }
                            }
                            .buttonStyle(.plain)
                            
                            Button {
                                viewModel.toggleCameraPosition()
                            } label: {
                                VStack {
                                    Image(systemName: "rectangle.stack.badge.play.fill")
                                        .font(.largeTitle)
                                        .symbolRenderingMode(.hierarchical)
                                    Text("Flip")
                                }
                            }
                            .buttonStyle(.plain)
                            
                            Button {
                                viewModel.toggleCameraPosition()
                            } label: {
                                VStack {
                                    Image(systemName: "speaker.wave.2.circle.fill")
                                        .font(.largeTitle)
                                        .symbolRenderingMode(.hierarchical)
                                    Text("Speaker")
                                }
                            }
                            .buttonStyle(.plain)
                        }
                        .padding(.top)
                        
                        HangUpIconView(viewModel: viewModel)
                            .scaleEffect(1.4)
                            .padding(.bottom)
                    }
                    .frame(maxWidth: .infinity)
                    //.frame(height: 85)
                    .background(.quaternary)
                }
                .toolbar {
                    ToolbarItem(placement: .topBarLeading) {
                        Button {
                            
                        } label: {
                            Image(systemName: "chevron.backward")
                        }
                        .buttonStyle(.plain)
                    }
                    
                    ToolbarItemGroup(placement: .topBarTrailing) {
                        Button {
                            
                        } label: {
                            Text(tv)
                        }
                        .buttonStyle(.plain)
                        
                        Button {
                            
                        } label: {
                            Text(eightEmoji)
                        }
                        .buttonStyle(.plain)
                        
                        Button {
                            
                        } label: {
                            Text(castle)
                        }
                        .buttonStyle(.plain)
                        
                        Button {
                            
                        } label: {
                            Text(animal)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }
}

