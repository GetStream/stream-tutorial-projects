//
//  WhatsAppTopBar.swift
//  BasicAdvancedTheming
//
//  Created by amos.gyamfi@getstream.io on 6.9.2023.
//

import SwiftUI

struct WhatsAppTopBar: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    WhatsAppTopBar()
}
