import SwiftUI
import StreamVideo
import StreamVideoSwiftUI

@main
struct BasicAdvancedThemingApp: App {
    @ObservedObject var viewModel: CallViewModel

    private var client: StreamVideo
    private let apiKey: String = "mmhfdzb5evj2" // The API key can be found in the Credentials section
    private let userId: String = "Carnor_Jax" // The User Id can be found in the Credentials section
    private let token: String = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiQ2Fybm9yX0pheCIsImlzcyI6InByb250byIsInN1YiI6InVzZXIvQ2Fybm9yX0pheCIsImlhdCI6MTY5Mzk5MzAxMCwiZXhwIjoxNjk0NTk3ODE1fQ.tFcmxdjJL8FvbtWKkNoIAPL0Oe5KW_1Ge5ah6yhRPCk" // The Token can be found in the Credentials section
    private let callId: String = "5XWyulUyKrFY" // The CallId can be found in the Credentials section
    
    
    init() {
        // Simple theming: Change the local user avatar
        let user = User(
            id: userId,
            name: "Martin", // name and imageURL are used in the UI
            imageURL: .init(string: "https://picsum.photos/id/64/200/200")
        )
        
        
        // MARK: Create an instance of the Colors struct
        var customColor = Colors()
        // Define the custom color you want to use
        let pineGreen = Color(red: 0.0, green: 0.408, blue: 0.28)
        // Swap the standard built-in color with the custom color
        // Color for xmark (close icon), invite button, cancel search, and remote participant's avatar
        customColor.tintColor = pineGreen
        // Slashed icons: Microphone and video
        customColor.accentRed = .orange
        // Mute/unmute me button
        customColor.secondaryButton = pineGreen
        // Call controls background
        customColor.callControlsBackground = pineGreen
        // Online indicator icon
        customColor.onlineIndicatorColor = pineGreen
        // Background of an active call
        customColor.callBackground = UIColor(pineGreen.opacity(0.5))
        // Background of form and search field
        customColor.background1 = UIColor(pineGreen.opacity(0.25))
        // Color for the reject call icon
        customColor.hangUpIconColor = .orange
        
        // MARK: Create an instance of the Images class
        let customImage = Images()
        customImage.acceptCall = Image(systemName: "teletype.answer.circle.fill")
        // Reject call icon
        customImage.hangup = Image(systemName: "teletype.circle.fill")
        customImage.micTurnOn = Image(systemName: "music.mic.circle.fill")
        customImage.micTurnOff = Image(systemName: "mic.fill.badge.xmark")
        // An icon for viewing the call participants
        customImage.participants = Image(systemName: "person.2.crop.square.stack.fill")
        customImage.searchIcon = Image(systemName: "sparkle.magnifyingglass")
        // Clear search icon
        customImage.searchCloseIcon = Image(systemName: "person.fill.xmark")
        customImage.speakerOn = Image(systemName: "speaker.wave.2.circle")
        customImage.speakerOff = Image(systemName: "speaker.slash.circle")
        customImage.videoTurnOn = Image(systemName: "video.fill.badge.checkmark")
        customImage.videoTurnOff = Image(systemName: "video.slash.circle.fill")
        // Cancel icon
        customImage.xmark = Image(systemName: "xmark.app.fill")
        customImage.toggleCamera = Image(systemName: "camera.on.rectangle.fill")
        
        // MARK: Create an instance of the Fonts struct
        var customFont = Fonts()
        // Remote participant's label
        customFont.caption1 = .custom("SmoochSans-Bold", size: 24)
        // Participants' names
        customFont.bodyBold = .custom("SmoochSans-Bold", size: 24)
        // Invite and mute button labels
        customFont.headline = .custom("SmoochSans-Bold", size: 24)
        
        // MARK: Create an instance of the Sounds class
        let customSound = Sounds()
        // Tell the SDK to pick the custom ring tone
        customSound.bundle = Bundle.main
        // Swap the outgoing call sound with the custom one
        customSound.outgoingCallSound = "ringing.mp3"
        
        // Create an instance of the appearance class
        let customAppearance = Appearance(colors: customColor, images: customImage, fonts: customFont, sounds: customSound)

        // Initialize Stream Video client
        self.client = StreamVideo(
            apiKey: apiKey,
            user: user,
            token: .init(stringLiteral: token)
        )
        
        // MARK: Added by Amos for customization
        _ = StreamVideoUI(
            streamVideo: client,
            appearance: customAppearance
        )
        
        self.viewModel = .init()
    }

    var body: some Scene {
        WindowGroup {
            VStack {
                if viewModel.call != nil {
                    CallContainer(viewFactory: DefaultViewFactory.shared, viewModel: viewModel)
                } else {
                    Text("loading...")
                }
            }.onAppear {
                Task {
                    guard viewModel.call == nil else { return }
                    //viewModel.joinCall(callType: .default, callId: callId)
                    
                    // MARK: Request an outgoing call screen
                    viewModel.startCall(callType: .default, callId: callId, members: [], ring: true)
                }
            }
        }
    }
}
