import SwiftUI
import StreamVideo
import StreamVideoSwiftUI

class CustomViewFactory: ViewFactory {

    func makeOutgoingCallView(viewModel: CallViewModel) -> some View {
        // Here you can also provide your own custom view.
        // In this example, we are re-using the standard one, while also adding an overlay.
        let outgoingView = DefaultViewFactory.shared.makeOutgoingCallView(viewModel: viewModel)
        return outgoingView.overlay(
            OutgoingCallUI()
        )
    }
}
