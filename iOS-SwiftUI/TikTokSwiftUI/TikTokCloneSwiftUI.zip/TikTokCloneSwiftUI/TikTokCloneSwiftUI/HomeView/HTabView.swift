//
//  HTabView.swift
//  TikTokCloneSwiftUI
//
//  Created by Amos Gyamfi on 31.5.2024.
//

import SwiftUI

struct HTabView: View {
    var body: some View {
        TabView {
            FirstVideoView()
            SecondVideoView()
            ThirdVideoView()
            SelfieVideoView()
            FireworksVideoView()
        }
        .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
        .ignoresSafeArea()
    }
    
    
}

#Preview {
    HTabView()
}
