//
//  FollowingForYouView.swift
//  TikTokCloneSwiftUI
//
//  Created by Amos Gyamfi on 31.5.2024.
//

import SwiftUI

struct FollowingForYouView: View {
    
    @State var top = 0
    
    var body: some View {
        NavigationStack {
            FeedsView()
                .toolbar {
                    ToolbarItem(placement: .topBarLeading) {
                        Button {
                            //
                        } label: {
                            Text("Live")
                        }
                        .buttonStyle(.plain)
                    }
                    
                    ToolbarItem(placement: .principal) {
                        HStack {
                            Button {
                                self.top = 0
                            } label: {
                                Text("Following")
                                    .fontWeight(self.top == 0 ? .bold : .none)
                                    .foregroundStyle(self.top == 0 ? .white : .white.opacity(0.5))
                                    .padding(.vertical)
                            }
                            .buttonStyle(.plain)
                            
                            Button {
                                self.top = 1
                            } label: {
                                Text("For You")
                                    .fontWeight(self.top == 1 ? .bold : .none)
                                    .foregroundStyle(self.top == 1 ? .white : .white.opacity(0.5))
                                    .padding(.vertical)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
        }
    }
}

#Preview {
    FollowingForYouView()
        .preferredColorScheme(.dark)
}
