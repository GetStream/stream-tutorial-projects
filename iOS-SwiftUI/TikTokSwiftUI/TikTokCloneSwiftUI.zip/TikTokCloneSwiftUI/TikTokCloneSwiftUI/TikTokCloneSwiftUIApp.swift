//
//  TikTokCloneSwiftUIApp.swift
//  TikTokCloneSwiftUI
//
//  Created by Amos Gyamfi on 31.5.2024.
//

import SwiftUI

@main
struct TikTokCloneSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
           FollowingForYouView()
        }
    }
}
