//
//  TwitterAndMediumReactionsApp.swift
//  TwitterAndMediumReactions
//
//  Created by amos.gyamfi@getstream.io on 10.7.2022.
//

import SwiftUI

@main
struct TwitterAndMediumReactionsApp: App {
    var body: some Scene {
        WindowGroup {
            TwitterContentView()
        }
    }
}
