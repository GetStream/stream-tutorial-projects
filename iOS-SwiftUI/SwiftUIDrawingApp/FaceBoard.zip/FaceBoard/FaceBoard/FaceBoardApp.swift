//
//  FaceBoardApp.swift
//  FaceBoard
//
//  Created by amos.gyamfi@getstream.io on 22.1.2024.
//

import SwiftUI
import StreamVideo
import StreamVideoSwiftUI

@main
struct FaceBoardApp: App {
    var body: some Scene {
        WindowGroup {
            ZStack {
                CallContainerSetup()
                FreeFormDrawingView(viewModel: CallViewModel())
            }
        }
    }
}
