//
//  CanvasManager.swift
//  PKDraw
//


/*import UIKit
import PencilKit

class CanvasManager: NSObject, PKCanvasViewDelegate {

    var canvasView: PKCanvasView
    
    override init() {
        canvasView = PKCanvasView()
        super.init()
        canvasView.delegate = self
    }
    
    func canvasViewDidBeginUsingTool(_ canvasView: PKCanvasView) {
        print("canvasViewDidBeginUsingTool")
    }
    
    func canvasViewDidFinishRendering(_ canvasView: PKCanvasView) {
        print("canvasViewDidFinishRendering")
    }
    
    func canvasViewDidEndUsingTool(_ canvasView: PKCanvasView) {
        print("canvasViewDidEndUsingTool")
    }
    
    func canvasViewDrawingDidChange(_ canvasView: PKCanvasView) {
        print("canvasViewDrawingDidChange")
    }
}*/
