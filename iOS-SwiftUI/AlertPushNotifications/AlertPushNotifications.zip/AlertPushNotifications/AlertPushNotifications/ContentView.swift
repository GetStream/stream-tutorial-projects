//
//  ContentView.swift
//  AlertPushNotifications
//
//  Created by amos.gyamfi@getstream.io on 23.10.2023.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("**All Hands**: \(Date.now.formatted())")
            .padding()
    }
}

#Preview {
    ContentView()
}
