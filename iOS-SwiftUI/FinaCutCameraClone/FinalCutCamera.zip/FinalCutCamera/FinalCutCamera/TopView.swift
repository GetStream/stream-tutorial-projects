//
//  HomeView.swift
//  FinalCutCamera
//
//  Created by Amos Gyamfi on 7.8.2024.
//

import SwiftUI

struct TopView: View {
    var body: some View {
        VStack {
            HStack(alignment: .top) {
                HStack {
                    Image(systemName: "hourglass.bottomhalf.filled")
                    Text("3h")
                    Text("13m")
                }
                .font(.caption)
                .padding(EdgeInsets(top: 8, leading: 12, bottom: 8, trailing: 12))
                .background(
                    RoundedRectangle(cornerRadius: 8, style: .continuous)
                        .fill(.ultraThinMaterial)
                )
                
                Spacer()
                
                VStack {
                    Spacer()
                    
                    HStack(spacing: 2) {
                        Image(systemName: "rectangle.ratio.4.to.3.fill")
                        Image(systemName: "rectangle.ratio.4.to.3.fill")
                    }
                    .font(.caption2)
                    .foregroundColor(Color(.systemGreen))
                }
                .padding(EdgeInsets(top: 0, leading: 6, bottom: 8, trailing: 6))
                .frame(height: 80)
                .background(
                    RoundedRectangle(cornerRadius: 8, style: .continuous)
                        .fill(.ultraThinMaterial)
                )
            }
        }
    }
}

#Preview {
    TopView()
        .preferredColorScheme(.dark)
}

