//
//  RecordingTimerView.swift
//  FinalCutCamera
//
//  Created by Amos Gyamfi on 13.8.2024.
//

import SwiftUI
import StreamVideo
import StreamVideoSwiftUI

struct RecordingTimerView: View {

    var body: some View {
        Text(Date.now, style: .timer)
            .monospacedDigit()
            .padding(EdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16))
            .background(
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .fill(.red)
            )
            .contentTransition(.interpolate)
    }
}

#Preview {
    RecordingTimerView()
        .preferredColorScheme(.dark)
}
