//
//  ZoomView.swift
//  FinalCutCamera
//
//  Created by Amos Gyamfi on 13.8.2024.
//

import SwiftUI

struct ZoomView: View {
    var body: some View {
        HStack {
            Image(systemName: "circle.fill")
                .font(.system(size: 60))
                .foregroundStyle(.ultraThinMaterial)
                .overlay(Image(systemName: "plus.magnifyingglass")
                    .font(.title2))
                
            Spacer()
            
            HStack(spacing: 32) {
                VStack(spacing: 0) {
                    Text("13")
                    Text("MM")
                }
                
                VStack(spacing: 0) {
                    Text("24")
                    Text("MM")
                }
                .foregroundStyle(Color(.systemOrange))
                
                VStack(spacing: 0) {
                    Text("77")
                    Text("MM")
                }
            }
            .font(.caption)
            .padding(EdgeInsets(top: 16, leading: 28, bottom: 16, trailing: 28))
            .background(
                RoundedRectangle(cornerRadius: 32, style: .continuous)
                    .fill(.ultraThinMaterial)
            )
            
            Spacer()
            
            Image(systemName: "circle.fill")
                .font(.system(size: 60))
                .foregroundStyle(.ultraThinMaterial)
                .overlay(Image(systemName: "chevron.up")
                    .font(.title2))
        }
    }
}

#Preview {
    ZoomView()
        .preferredColorScheme(.dark)
}
