//
//  FinalCutCameraApp.swift
//  FinalCutCamera
//
//  Created by Amos Gyamfi on 7.8.2024.
//

import SwiftUI
import StreamVideo
import StreamVideoSwiftUI

@main
struct FinalCutCameraApp: App {
    @State var call: Call
    @ObservedObject var state: CallState
    @State var callCreated: Bool = false
    @State private var isRecording = false
    
    private var client: StreamVideo
    
    private let apiKey: String = "mmhfdzb5evj2"
    private let token: String = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiTmF0YXNpX0RhYWxhIiwiaXNzIjoiaHR0cHM6Ly9wcm9udG8uZ2V0c3RyZWFtLmlvIiwic3ViIjoidXNlci9OYXRhc2lfRGFhbGEiLCJpYXQiOjE3MjM3MzA2OTUsImV4cCI6MTcyNDMzNTUwMH0.z7DpiheX4KzI2s20UklHpUk2SCuA1O5TcrV7ip5kNnc"
    private let userId: String = "Natasi_Daala"
    private let callId: String = "z6yuJAJvuZEL"
    
    init() {
        let user = User(
            id: userId,
            name: "Martin", // name and imageURL are used in the UI
            imageURL: .init(string: "https://getstream.io/static/2796a305dd07651fcceb4721a94f4505/a3911/martin-mitrevski.webp")
        )
        
        // Initialize Stream Video client
        self.client = StreamVideo(
            apiKey: apiKey,
            user: user,
            token: .init(stringLiteral: token)
        )
        
        // Initialize the call object
        let call = client.call(callType: "default", callId: callId)
        
        self.call = call
        self.state = call.state
    }
    
    var body: some Scene {
        WindowGroup {
            NavigationStack {
                ZStack {
                    VStack {
                        if callCreated {
                            ZStack {
                                ParticipantsView(
                                    call: call,
                                    participants: call.state.remoteParticipants,
                                    onChangeTrackVisibility: changeTrackVisibility(_:isVisible:)
                                )
                                FloatingParticipantView(participant: call.state.localParticipant)
                            }
                        } else {
                            Text("loading...")
                        }
                    }.onAppear {
                        Task {
                            guard callCreated == false else { return }
                            try await call.join(create: true)
                            callCreated = true
                        }
                    }
                    
                    VStack {
                        TopView()
                        Spacer()
                        ZoomView()
                        //RecordingView()
                        HStack {
                            Image(.img)
                                .resizable()
                                .frame(width: 64, height: 64)
                                .cornerRadius(8)
                            
                            Spacer()
                            
                            Button {
                                isRecording.toggle()
                                isRecording ? stopRecording() : startRecording()
                            } label: {
                                ZStack {
                                    Image(systemName: isRecording ? "square.fill" : "circle.fill")
                                        .font(.system(size: 42))
                                        .foregroundStyle(.red)
                                        .contentTransition(.symbolEffect(.replace))
                                    Image(systemName: "circle")
                                        .font(.system(size: 74))
                                }
                            }
                            .buttonStyle(.plain)
                            
                            Spacer()
                            
                            ZStack {
                                Image(systemName: "circle.fill")
                                    .font(.system(size: 68))
                                    .foregroundStyle(.ultraThinMaterial)
                                Image(systemName: "arrow.trianglehead.2.clockwise.rotate.90")
                                    .font(.title)
                                
                            }
                        }
                    }
                    .padding(.horizontal)
                }
                .navigationBarTitleDisplayMode(.inline)
                .toolbar{
                    if !isRecording {
                        ToolbarItem(placement: .navigationBarLeading) {
                            Image(systemName: "video.fill.badge.plus")
                        }
                        
                        ToolbarItem(placement: .principal) {
                            Text("HEVC . HDR . 4K . 30fps")
                                .font(.caption2)
                                .padding(EdgeInsets(top: 8, leading: 12, bottom: 8, trailing: 12))
                                .background(
                                    RoundedRectangle(cornerRadius: 24, style: .continuous)
                                        .fill(.ultraThinMaterial)
                                )
                        }
                        
                        ToolbarItem(placement: .navigationBarTrailing) {
                            Image(systemName: "gear")
                        }
                    } else {
                        ToolbarItem(placement: .principal) {
                            RecordingTimerView()
                        }
                    }
                    
                    
                }
            }
        }
    }
    
    func startRecording() {
        Task {
            try await call.startRecording()
        }
    }
    
    func stopRecording() {
        Task {
            try await call.stopRecording()
        }
    }
    
    /// Changes the track visibility for a participant (not visible if they go off-screen).
    /// - Parameters:
    ///  - participant: the participant whose track visibility would be changed.
    ///  - isVisible: whether the track should be visible.
    private func changeTrackVisibility(_ participant: CallParticipant?, isVisible: Bool) {
        guard let participant else { return }
        Task {
            await call.changeTrackVisibility(for: participant, isVisible: isVisible)
        }
    }
}
