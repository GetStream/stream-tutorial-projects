//
//  PollsUIFactory.swift
//  PollsSwiftUI
//
//  Created by Amos Gyamfi on 28.6.2024.
//

import Foundation
import SwiftUI
import StreamChat
import StreamChatSwiftUI

class CustomPollsFactory: ViewFactory {

    @Injected(\.chatClient) public var chatClient

    private init() {}

    public static let shared = CustomPollsFactory()

    func makeComposerPollView(
            channelController: ChatChannelController,
            messageController: ChatMessageController?
    ) -> some View {
        CustomComposerPollView(channelController: channelController, messageController: messageController)
    }

}
