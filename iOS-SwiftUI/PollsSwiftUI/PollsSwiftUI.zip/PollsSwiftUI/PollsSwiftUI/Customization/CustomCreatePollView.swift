//
//  CustomCreatePollView.swift
//  PollsSwiftUI
//
//  Created by Amos Gyamfi on 28.6.2024.
//

import SwiftUI
import StreamChat
import StreamChatSwiftUI

struct CustomCreatePollView: View {
    let chatController = ChatUserController.self
    let messageController = ChatMessageController.self
    
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}


