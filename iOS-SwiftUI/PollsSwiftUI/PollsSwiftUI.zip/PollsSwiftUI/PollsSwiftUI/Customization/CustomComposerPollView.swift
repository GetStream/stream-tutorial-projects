//
//  CustomComposerPollView.swift
//  PollsSwiftUI
//
//  Created by Amos Gyamfi on 28.6.2024.
//

import SwiftUI
import StreamChat

struct CustomComposerPollView: View {
    @State private var showsOnAppear = true
    @State private var showsCreatePoll = false
    
    let channelController: ChatChannelController
    var messageController: ChatMessageController?
    
    var body: some View {
        
        VStack {
            Spacer()
            Button {
                showsCreatePoll = true
            } label: {
                Text("Create poll")
            }

            Spacer()
        }
        .fullScreenCover(isPresented: $showsCreatePoll) {
            //CustomCreatePollView(chatController: channelController, messageController: messageController)
            CustomCreatePollView()
        }
        .onAppear {
            guard showsOnAppear else { return }
            showsOnAppear = false
            showsCreatePoll = true
        }
    }
}
