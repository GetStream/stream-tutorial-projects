// server.js
const express = require("express");
const app = express();

// Stream Chat server SDK
const StreamChat = require("stream-chat").StreamChat;
const serverClient = new StreamChat("rp2famm7xfpa", "9sg2ykgmebaamfw6awfebb9ksxxahukwzd5zfhk4ccwuhtspv1jr35dpvbbzxeh8");
app.use(express.static(__dirname + "/public"));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.get("/", (req, res) => {
  res.sendFile("/index.html");
});

app.listen(8800, () => {
  console.log("Example app listening on port 8800!");
});

app.get("/token", (req, res) => {
  const { username } = req.query;
  if (username) {
    const token = serverClient.createToken(username);
    res.status(200).json({ token, status: "sucess" });
  } else {
    res.status(401).json({ message: "invalid request", status: "error" });
  }
});