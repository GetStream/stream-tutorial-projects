//
//  ChatChannelVC.swift
//  SwiftChatMessaging
//
//  Created by Amos Gyamfi on 23.8.2024.
//

import UIKit
import StreamChatUI

class DemoChannelVC: ChatChannelVC {}
