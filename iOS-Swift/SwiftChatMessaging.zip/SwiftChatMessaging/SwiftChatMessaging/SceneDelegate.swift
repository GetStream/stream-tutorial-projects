//
//  SceneDelegate.swift
//  SwiftChatMessaging
//
//  Created by Amos Gyamfi on 22.8.2024.
//

import UIKit
import StreamChat

// For Customization
import StreamChatUI

// Define What you want to customize
func applyChatCustomizations() {
    // Customize the color of the outgoing chat bubble
    Appearance.default.colorPalette.background6 = .green
    
    // Customize images: Send button, reaction icons
    Appearance.default.images.sendArrow = UIImage(systemName: "arrowshape.turn.up.right")!
    Appearance.default.images.reactionLoveBig = UIImage(systemName: "heart")!
    Appearance.default.images.reactionLoveSmall = UIImage(systemName: "heart")!
    
    Components.default.channelVC = DemoChannelVC.self
}

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

    func scene(
        _ scene: UIScene,
        willConnectTo session: UISceneSession,
        options connectionOptions: UIScene.ConnectionOptions
    ) {
        // Create a config object and initialize it with an API key
        let config = ChatClientConfig(apiKey: .init("uun7ywwamhs9"))

        /// user id and token for the user
        let userId = "tutorial-droid"
        let token: Token =
            "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoidHV0b3JpYWwtZHJvaWQifQ.WwfBzU1GZr0brt_fXnqKdKhz3oj0rbDUm2DqJO_SS5U"
        
        // For customization
        applyChatCustomizations()
        
        /// Step 1: create an instance of ChatClient and share it using the singleton
        ChatClient.shared = ChatClient(config: config)

        /// Step 2: connect to chat
        ChatClient.shared.connectUser(
            userInfo: UserInfo(
                id: userId,
                name: "Tutorial iOS",
                imageURL: URL(string: "https://picsum.photos/id/64/200/200")
            ),
            token: token
        )

        /// Step 3: create the ChannelList view controller
        let channelList = DemoChannelList()
        let query = ChannelListQuery(filter: .containMembers(userIds: [userId]))
        channelList.controller = ChatClient.shared.channelListController(query: query)

        /// Step 4: similar to embedding with a navigation controller using Storyboard
        window?.rootViewController = UINavigationController(rootViewController: channelList)
    }
}

