import StreamChat
import StreamChatUI
import UIKit

class DemoChannelList: ChatChannelListVC {}
