//
//  ViewController.swift
//  VoiceMessaging
//
//  Created by amos.gyamfi@getstream.io on 4.8.2023.
//

import StreamChat
import StreamChatUI
import UIKit

class DemoChannelList: ChatChannelListVC {}

