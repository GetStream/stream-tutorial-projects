
//Incoming Call
import UIKit
import CallKit


class ViewController: UIViewController, CXProviderDelegate {
    
    override func viewDidLoad() {
        // 1: Create an incoming call update object. This object stores different types of information about the caller. You can use it in setting whether the call has a video.
        let update = CXCallUpdate()
        
        // Specify the type of information to display about the caller during an incoming call. The different types of information available include `.generic`. For example, you could use the caller's name for the generic type. During an incoming call, the name displays to the other user. Other available information types are emails and phone numbers.
        update.remoteHandle = CXHandle(type: .generic, value: "Amos Gyamfi")
        //update.remoteHandle = CXHandle(type: .emailAddress, value: "amosgyamfi@gmail.com")
        //update.remoteHandle = CXHandle(type: .phoneNumber, value: "a+35846599990")
        
        
        // 2: Create and set configurations about how the calling application should behave
        let config = CallKit.CXProviderConfiguration()
        config.iconTemplateImageData = UIImage(named: "amosbw")!.pngData()
        config.includesCallsInRecents = true;
        config.supportsVideo = true;
        update.hasVideo = true
        
        
        // Provide a custom ringtone
        config.ringtoneSound = "ES_CellRingtone23.mp3";
        
        // 3: Create a CXProvider instance and set its delegate
        let provider = CXProvider(configuration: config)
        provider.setDelegate(self, queue: nil)

        
        // 4. Post local notification to the user that there is an incoming call. When using CallKit, you do not need to rely on only displaying incoming calls using the local notification API because it helps to show incoming calls to users using the native full-screen incoming call UI on iOS. Add the helper method below `reportIncomingCall` to show the full-screen UI. It must contain `UUID()` that helps to identify the caller using a random identifier. You should also provide the `CXCallUpdate` that comprises metadata information about the incoming call. You can also check for errors to see if everything works fine.
        provider.reportNewIncomingCall(with: UUID(), update: update, completion: { error in })
    }
    
    func providerDidReset(_ provider: CXProvider) {
    }
    
    // What happens when the user accepts the call by pressing the incoming call button? You should implement the method below and call the fulfill method if the call is successful.
    func provider(_ provider: CXProvider, perform action: CXAnswerCallAction) {
        action.fulfill()
        return
    }
    
    
    // What happens when the user taps the reject button? Call the fail method if the call is unsuccessful. It checks the call based on the UUID. It uses the network to connect to the end call method you provide.
    func provider(_ provider: CXProvider, perform action: CXEndCallAction) {
        action.fail()
        return
    }
    
}
 


/*
 // How to make outgoing calls
 import UIKit
 import CallKit
 
 class ViewController: UIViewController, CXProviderDelegate {
 func providerDidReset(_ provider: CXProvider) {
 
 }
 
 override func viewDidLoad() {
 
 // 1. Add a provider configuration
 let config = CallKit.CXProviderConfiguration()
 let provider = CXProvider(configuration: config)
 provider.setDelegate(self, queue: nil)
 // 2. Create a start call action and configure it with UUID and the user's handle. The handle parameter is a string that represents the recipient
 let callController = CXCallController()
 // Allows to uniquely identify the call
 let uuid = UUID()
 // CXHandle specifies the recipient
 let recipient = CXHandle(type: .generic, value: "Demo Outgoing Call")
 let startCallAction = CXStartCallAction(call: uuid, handle: recipient)
 let transaction = CXTransaction(action: startCallAction)
 
 // To make an outgoing call, the app requests a `CXStartCallAction` from the `CXCallController` as a transaction. The transaction object helps to hold a call when there are multiple calls attempting to occur at the same time.
 callController.request(transaction, completion: { error in
 if let error = error {
 print("Error requesting transaction: \(error)")
 } else {
 print("Requested transaction successfully")
 }
 })
 
 // How to connect an outgoing call after a certain time interval
 DispatchQueue.main.asyncAfter(deadline: .now() + 10) {
 // Show the call is connected after 10 seconds
 provider.reportOutgoingCall(with: callController.callObserver.calls[0].uuid, connectedAt: nil)
 }
 }
 }
 */





