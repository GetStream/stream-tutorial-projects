<?php

require_once(__DIR__ . "/vendor/autoload.php");

// Set your Stream Chat API key and secret
$STREAM_API_KEY = "pp2fast7xfza";
$STREAM_API_SECRET = "4sg2ykgmea8amfw6awfeyb9ksxxahuawzd5zfhk4ccwuht8pv9jr35dpv7bzx7h8";

// Initialize the SDK
$client = new \GetStream\StreamChat\Client(
    $STREAM_API_KEY,
    $STREAM_API_SECRET
);

// Create a user token
if (isset($_REQUEST["create-token"])) {
  die(json_encode([
      "status" => "success",
      "token"  => $client->createToken($_REQUEST["create-token"])
  ]));
}

?>