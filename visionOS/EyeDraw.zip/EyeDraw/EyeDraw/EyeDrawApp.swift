//
//  EyeDrawApp.swift
//  EyeDraw
//
//  Created by Amos Gyamfi on 3.2.2024.
//

import SwiftUI

@main
struct EyeDrawApp: App {
    var body: some Scene {
        WindowGroup {
            FreeFormDrawingView()
        }
    }
}
