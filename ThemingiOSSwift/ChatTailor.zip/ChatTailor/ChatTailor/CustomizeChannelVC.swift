//
//  CustomizeChannelVC.swift
//  ChatTailor
//  MARK: Customizing the Channel list screen with the view controller class


import StreamChat
import StreamChatUI
import UIKit

// This class must conform to the iOS SDK's chat channel view controller
class CustomizeChannelVC: ChatChannelVC {}
