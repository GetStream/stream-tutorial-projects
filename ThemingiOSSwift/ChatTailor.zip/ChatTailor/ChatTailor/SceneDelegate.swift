//
//  SceneDelegate.swift
//  ChatTailor
//

import UIKit
import StreamChat
import StreamChatUI

// Perform all basic customizations in this function
func applyChatCustomizations() {
    
    // MARK: Customize Background Color
   
    // Change the outgoing chat message bubble to a teal color
    Appearance.default.colorPalette.background6 = .systemTeal
    
    // Change the background of attachments for outgoing chat message bubbles. Outgoing chat bubbles with attachments
    Appearance.default.colorPalette.background1 = .systemTeal
    
    // Change the background color of the incoming chat message bubble and jump-to-botom or scroll-to-bottom button
    Appearance.default.colorPalette.background8 = .systemTeal
    // Change the background of: Channel list, compose area, conversations area, context menu
    Appearance.default.colorPalette.background = .systemGray6
    
    // MARK: Customize Text Color and the Color of UI Elements
    
    // Change the text for navigation title, outgoing chat bubble, incoming chat bubble, context menu, compose area, Giphy, reveal button for swipe-to-delete action
    Appearance.default.colorPalette.text = .green
    
    // Change the text color for the Giphy logo text date. When a message was sent
    Appearance.default.colorPalette.staticColorText = .systemCyan
    
    // Change the text color of the channel list message summary, timestamps, placeholder for the compose area, Instant Commands label, Giphy label, and previous online status (last seen)
    Appearance.default.colorPalette.subtitleText = .magenta
    
    // Change the text color of the sent indicator (single checkmark) for the channel list, system-wide messages (deleted message) and conversations area
    Appearance.default.colorPalette.textLowEmphasis = .orange
    
    // Change the text color of the read indicator
    Appearance.default.colorPalette.accentPrimary = .link
    
    // MARK: Customizing Fonts
    
    // Modify the body font: Compose area text, incoming and outgoing messages, context menu
    //Appearance.default.fonts.body = UIFont(name: "Helvetica Neue", size: 32)!
    Appearance.default.fonts.body = UIFont(name: "Freehand-Regular", size: 24)!
    
    // MARK: Customizing the SDK-provided SF Symbols
    
    // Swap the send icon
    Appearance.default.images.sendArrow = UIImage(systemName: "paperplane.circle.fill")!
    
    // Swap reaction icons with SF Symbols
    Appearance.default.images.reactionLoveBig = UIImage(systemName: "bolt.heart.fill")!
    Appearance.default.images.reactionLoveSmall = UIImage(systemName: "bolt.heart.fill")!
    
    // Replace reaction icons with Google Material Symbols
    Appearance.default.images.reactionWutBig = (UIImage(named:"approval_delegation"))!
    Appearance.default.images.reactionWutSmall = (UIImage(named:"approval_delegation"))!
    
    Components.default.channelVC = CustomizeChannelVC.self
}


class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

    func scene(
        _ scene: UIScene,
        willConnectTo session: UISceneSession,
        options connectionOptions: UIScene.ConnectionOptions
    ) {
        let config = ChatClientConfig(apiKey: .init("dz5f4d5kzrue"))

        /// user id and token for the user
        let userId = "tutorial-droid"
        let token: Token =
            "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoidHV0b3JpYWwtZHJvaWQifQ.NhEr0hP9W9nwqV7ZkdShxvi02C5PR7SJE7Cs4y7kyqg"

        /// Step 1: create an instance of ChatClient and share it using the singleton
        //ChatClient.shared = ChatClient(config: config)
        applyChatCustomizations()
        ChatClient.shared = ChatClient(config: config)

        /// Step 2: connect to chat
        ChatClient.shared.connectUser(
            userInfo: UserInfo(
                id: userId,
                name: "Tutorial Droid",
                imageURL: URL(string: "https://bit.ly/2TIt8NR")
            ),
            token: token
        )

        /// Step 3: create the ChannelList view controller
        let channelList = DemoChannelList()
        let query = ChannelListQuery(filter: .containMembers(userIds: [userId]))
        channelList.controller = ChatClient.shared.channelListController(query: query)

        /// Step 4: similar to embedding with a navigation controller using Storyboard
        window?.rootViewController = UINavigationController(rootViewController: channelList)
    }
}

