//
//  TwitterLikeReactionApp.swift
//  TwitterLikeReaction
//
//  Created by amos.gyamfi@getstream.io on 24.4.2022.
//

import SwiftUI

@main
struct TwitterLikeReactionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
