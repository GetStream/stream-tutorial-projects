//
//  MediumCumulativeClapApp.swift
//  MediumCumulativeClap
//
//  Created by amos.gyamfi@getstream.io on 24.4.2022.
//

import SwiftUI

@main
struct MediumCumulativeClapApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
