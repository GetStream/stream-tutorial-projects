import SwiftUI
import CallKit
import AVFoundation // Import AVFoundation for audio session management

class IncomingCallViewController: UIViewController, CXProviderDelegate {

    var provider: CXProvider?

    override func viewDidLoad() {
        super.viewDidLoad()
        setupProvider()
        simulateIncomingCall()
    }

    func setupProvider() {
        // 1. Configure the provider
        let config = CXProviderConfiguration()
        config.supportsVideo = false // Example configuration
        config.maximumCallsPerCallGroup = 1
        config.supportedHandleTypes = [.generic] // Or .phoneNumber, .emailAddress
        // You might want to add an icon mask and ringtone sound
        // config.iconTemplateImageData = // Data for icon
        // config.ringtoneSound = // Filename for ringtone
        config.ringtoneSound = "ringing.m4a"
        provider = CXProvider(configuration: config)
        provider?.setDelegate(self, queue: nil) // Use nil for main queue
    }

    func simulateIncomingCall() {
        guard let provider = provider else {
            print("Provider not initialized")
            return
        }

        // 2. Create a call update
        let callUpdate = CXCallUpdate()
        callUpdate.remoteHandle = CXHandle(type: .generic, value: "Demo Incoming Call")
        // You can set hasVideo, localizedCallerName etc.
        // callUpdate.localizedCallerName = "Jane Doe"

        // 3. Report the incoming call
        let callUUID = UUID() // Unique ID for this call
        provider.reportNewIncomingCall(with: callUUID, update: callUpdate) { error in
            if let error = error {
                print("Error reporting incoming call: \(error.localizedDescription)")
            } else {
                print("Incoming call reported successfully")
                // You might schedule a timeout for the user to answer
            }
        }
    }

    // MARK: - CXProviderDelegate Methods

    func providerDidReset(_ provider: CXProvider) {
        print("Provider did reset")
        // Handle provider reset, possibly stop audio, clean up calls
    }

    // Called when the user answers the call
    func provider(_ provider: CXProvider, perform action: CXAnswerCallAction) {
        print("Incoming call answered")

        // Configure your audio session (example)
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(.playAndRecord, mode: .voiceChat, options: [])
            try audioSession.setActive(true)
            print("Audio session configured and activated for call")
            // Start your audio processing or connection here...

            // Fulfill the action once the call is conceptually "answered"
            action.fulfill()
        } catch {
            print("Error configuring audio session: \(error)")
            action.fail()
        }
    }

    // Called when the user ends the call
    func provider(_ provider: CXProvider, perform action: CXEndCallAction) {
        print("Incoming call ended")

        // Stop your audio processing or connection here...

        // Deactivate audio session (example)
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setActive(false)
            print("Audio session deactivated")
        } catch {
            print("Error deactivating audio session: \(error)")
        }

        // Fulfill the action
        action.fulfill()
    }
}

// SwiftUI wrapper for the ViewController
struct IncomingCallControllerRepresentable: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> IncomingCallViewController {
        return IncomingCallViewController()
    }

    func updateUIViewController(_ uiViewController: IncomingCallViewController, context: Context) {
        // No update logic needed for this example
    }
}

// The SwiftUI View
struct IncomingCallView: View {
    var body: some View {
        IncomingCallControllerRepresentable()
            .edgesIgnoringSafeArea(.all) // Make it full screen potentially
    }
}

struct IncomingCallView_Previews: PreviewProvider {
    static var previews: some View {
        IncomingCallView()
    }
}
