//
//  StreamCallSwiftUIApp.swift
//  StreamCallSwiftUI


import SwiftUI

@main
struct StreamCallSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            //OutgoingCallView()
            IncomingCallView()
        }
    }
}
