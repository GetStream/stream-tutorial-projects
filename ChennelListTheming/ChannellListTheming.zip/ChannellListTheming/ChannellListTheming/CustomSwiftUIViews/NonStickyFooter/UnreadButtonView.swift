//
//  UnreadButtonView.swift
//  ChannellListTheming
//
//

import SwiftUI

struct UnreadButtonView: View {
    var body: some View {
        Button {
            print("Jump to unread messages button tapped")
        } label: {
            Image(systemName: "arrow.up")
            Text("Jump to top")
        }
        .buttonStyle(.borderedProminent)
    }
}

struct UnreadButtonView_Previews: PreviewProvider {
    static var previews: some View {
        UnreadButtonView()
    }
}
