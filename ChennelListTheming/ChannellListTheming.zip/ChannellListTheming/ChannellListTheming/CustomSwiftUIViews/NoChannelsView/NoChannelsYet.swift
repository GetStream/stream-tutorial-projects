//
//  NoChannelsYet.swift
//  ChannellListTheming
//
//  Created by amos.gyamfi@getstream.io on 12.8.2022.
//

import SwiftUI

struct NoChannelsYet: View {
    var body: some View {
        VStack {
            Image("emptyChannels")
                .resizable()
                .aspectRatio(contentMode: .fit)
            
            Text("Sorry, No channels yet!!!")
        }
    }
}

struct NoChannelsYet_Previews: PreviewProvider {
    static var previews: some View {
        NoChannelsYet()
    }
}
