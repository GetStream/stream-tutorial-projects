//
//  CustomListRowSeparator.swift
//  ChannellListTheming
//
//  Created by amos.gyamfi@getstream.io on 8.8.2022.
//

import SwiftUI

struct CustomListRowSeparator: View {
    let deviceWidth = UIScreen.main.bounds.width
    let orangeGreen = LinearGradient(colors: [.orange, .green],
                                  startPoint: .topLeading,
                                  endPoint: .bottomTrailing)
    var body: some View {
        Rectangle()
            .fill(orangeGreen)
            .frame(width: deviceWidth, height: 1)
            .blendMode(.screen)
    }
}

struct CustomListRowSeparator_Previews: PreviewProvider {
    static var previews: some View {
        CustomListRowSeparator()
    }
}
