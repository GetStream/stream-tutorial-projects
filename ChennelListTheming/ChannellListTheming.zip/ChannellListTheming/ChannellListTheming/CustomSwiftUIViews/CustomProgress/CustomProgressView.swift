//
//  CustomProgressView.swift
//  ChannellListTheming
//
//  Created by amos.gyamfi@getstream.io on 10.8.2022.
//

import SwiftUI
struct DarkBlueShadowProgressViewStyle: ProgressViewStyle {
    func makeBody(configuration: Configuration) -> some View {
        ProgressView(configuration)
            .shadow(color: Color(red: 0, green: 0, blue: 0.6),
                    radius: 4.0, x: 1.0, y: 2.0)
    }
}

struct CustomProgressView: View {
    @State private var progress = 0.0
    var body: some View {
        VStack {
            ProgressView(value: progress)
                .progressViewStyle(DarkBlueShadowProgressViewStyle())
                .onAppear{
                    withAnimation(.easeInOut.delay(0.2)) {
                        progress += 1.0
                    }
                }
        }
    }
}

struct CustomProgressView_Previews: PreviewProvider {
    static var previews: some View {
        CustomProgressView()
    }
}
