//
//  EmptyPageView.swift
//  ChannellListTheming

import SwiftUI

struct EmptyPageView: View {
    var body: some View {
        Text("")
    }
}

struct EmptyPageView_Previews: PreviewProvider {
    static var previews: some View {
        EmptyPageView()
    }
}
